#import <Foundation/Foundation.h>
#import "EJBindingBase.h"


@interface EJBindingScreenshot : EJBindingBase{
    int gameHeight;
    int gameWidth;
}

@end
