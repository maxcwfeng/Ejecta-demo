ejecta.include('three.js');
ejecta.include('webgl_dae.js');
ejecta.include('ColladaLoader.js');
ejecta.include('test.js');
